
from game import Game

game = Game()

game.running = True
game.initialise()